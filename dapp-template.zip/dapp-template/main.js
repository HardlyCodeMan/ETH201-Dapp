var web3 = new Web3(Web3.givenProvider);

$(document).ready(function() {
    window.ethereum.enable();
});
